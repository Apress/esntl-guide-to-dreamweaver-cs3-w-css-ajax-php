-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 19, 2007 at 01:24 PM
-- Server version: 5.0.37
-- PHP Version: 5.2.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `egdwcs3`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `ch20_gallery`
-- 

DROP TABLE IF EXISTS `ch20_gallery`;
CREATE TABLE IF NOT EXISTS `ch20_gallery` (
  `photo_id` int(10) unsigned NOT NULL auto_increment,
  `filename` varchar(30) NOT NULL,
  `category` enum('GB','JPN') NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`photo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `ch20_gallery`
-- 

INSERT INTO `ch20_gallery` (`photo_id`, `filename`, `category`, `width`, `height`, `caption`, `description`) VALUES 
(1, 'basin.jpg', 'JPN', 350, 237, 'Water basin at Ryoanji temple, Kyoto', '<p>Most visitors to Ryoanji Temple go to see just one thing&#8212;the rock garden. It''s probably the most famous dry landscape (karesansui) garden&#8212;15 irregularly shaped rocks in a bed of gravel that''s raked every day. It''s been there since the 15th century, and is certainly remarkable. But Ryoanji has much more to offer. For me, the water basin just behind the main building is exquisite.</p><p>The basin is carved out of a circular piece of stone, but water trickles from a bamboo spout into a square cavity. Carved around the edge are four partial Chinese characters, which are completed by the square. Read together, they mean "I learn only to be contented"&#8212;knowledge for its own sake is sufficient. In other words, someone who learns to be contented is rich in spirit and character, whereas someone who may be materially wealthy is spiritually poor if they do not learn contentment.</p>'),
(2, 'buck_palace.jpg', 'GB', 400, 300, 'Buckingham Palace and St James''s Park', '<p>St James''s Park is my favourite among all the parks in central London. It lies on a gentle slope between The Mall and Birdcage Walk, and is home to many water birds, including a pair of pelicans. What makes St James''s so pleasant is its mix of trees, flowers, and lake. The paths curve gently, making it an oasis of calm amid the city bustle.</p>'),
(3, 'countrygarden.jpg', 'GB', 374, 283, 'A typical English country garden in Oxford', '<p>The quintessential English country garden is a study of organized chaos. The plants appear to grow haphazardly, just like wild flowers, but the colours and heights are carefully mixed to blend harmoniously.</p>'),
(4, 'daisydance.jpg', 'GB', 243, 273, 'Dancing round the daisies at Capel Manor', '<p>Capel Manor, just to the North of London, has 12 hectares (30 acres) of gardens and woodland. It''s home to the only specialist college of horticulture, floristry, garden design, and animal care in Greater London.</p><p>As well as formal themed gardens, you find the odd flight of fancy, such as this trio of girls sculpted out of intertwined branches, dancing merrily amid dandelions, buttercups, and daisies.</p>'),
(5, 'dome.jpg', 'GB', 320, 300, 'Leaden skies over the Dome in London', '<p>The Millennium Dome in Greenwich never lived up to expectations, but it''s a fascinating structure that dominates a bend in the Thames. The pylons that support the roof soar eerily into the sky. Perhaps it''s ET still trying to phone home, but the signal can''t get through the leaden skies...</p>'),
(6, 'eye_stjames.jpg', 'GB', 365, 249, 'The London Eye keeps watch over the Foreign Office', '<p>At the opposite end of St James''s Park to Buckingham Palace lies Whitehall&#8212;home to many government buildings, including the Foreign Office, the Treasury, and the Prime Minister''s official residence at 10 Downing Street. A newcomer keeping a watch over them all is the London Eye, the futuristic, yet elegant observation wheel.</p><p>The Eye stands 135 metres (443 feet) tall, and when it opened on 31 December 1999 was the world''s tallest observation wheel. It was originally given planning permission for only five years, but has since been made permanent.</p>'),
(7, 'fountains.jpg', 'JPN', 350, 265, 'Fountains in central Tokyo', '<p>Between the Imperial Palace and Tokyo Station is a small park with no grass, but an attractive selection of fountains. It was created to celebrate the wedding of Crown Prince Naruhito to Masako Owada in 1993.</p><p>The fountains bring a breath of cool, fresh air to the city on a hot day. At night, they are illuminated, and provide a restful break from a city that never seems to sleep.</p>'),
(8, 'hgs.jpg', 'GB', 400, 300, 'Hampstead Garden Suburb in North London', '<p>Hampstead Garden Suburb in North London celebrated its centenary in 2007. It was founded by Henrietta Barnett as a social experiment to create a beautiful and healthy place, where both rich and poor would be welcome. Although the houses were designed to form a unified ensemble, each one is different from its neighbour.</p><p>Many of the roads are lined with cherry trees, and each house is situated in a spacious garden. The unique environment has been preserved thanks to conservation orders. However, in recent years, even the houses intended as "artisans'' cottages" have become so expensive, it''s no longer a place the poor can afford to live.</p>'),
(9, 'kinkakuji.jpg', 'JPN', 270, 346, 'The Golden Pavilion in Kyoto', '<p>Kinkakuji&#8212;the Golden Pavilion&#8212;is probably one of Kyoto''s best-known sights. Originally built in 1397, it was burned down by a mentally disturbed monk in 1950. Yukio Mishima''s novel <em>The Temple of the Golden Pavilion</em> is based on a fictionalized account of the arson.</p><p>An exact replica was built on the same spot in 1955. The building itself, covered in gold leaf, looks rather ostentatious. The real beauty lies in its surroundings and the reflection of the pavilion in the glass-like surface of the lake.</p>'),
(10, 'maiko.jpg', 'JPN', 340, 205, 'Maiko&#8212;trainee geishas in Kyoto', '<p>The real joys of Kyoto lie in unexpected encounters. Shijo-dori is one of the main shopping streets, packed with local people and visitors. Just as I started to cross the road, I heard a little clatter behind me, and looked around. There were two young women in exquisite kimonos, their faces painted white, and with cupid-bow, red lips. The clatter came from the geta, the high wooden sandals they had on their feet. Just like everyone else, it seemed, they were out enjoying a morning''s window shopping.</p><p>This is a sight that you''ll rarely see anywhere else in Japan, except Kyoto. The young women were maiko, trainee geishas, who spend years studying traditional song and dance. It''s an unusual profession to have survived in a country that''s now so modern, but geisha are respected for preserving traditional arts - and in a most attractive way.</p>'),
(11, 'maiko_phone.jpg', 'JPN', 200, 263, 'Every maiko should have one&#8212;a mobile, of course', '<p>Maiko&#8212;trainee geishas in Kyoto&#8212;may be dedicated to the study and performance of traditional song and dance, but that doesn''t mean they ignore the modern world. As I was making my way through Higashiyama Ward, I spotted this maiko rushing along the street, deep in conversation on her mobile phone. Making arrangements for her next appointment, or indulging in a bit of girl''s talk?</p>'),
(12, 'mallgarden.jpg', 'GB', 384, 252, 'The Queen''s front garden on The Mall in London', '<p>This is the view from The Mall towards Constitution Hill, with Buckingham Palace just out of view on the left. The flower beds and neatly mowed lawn provide a formal space between the palace and Green Park, which lies behind the trees.</p><p>The flags were out in preparation for Trooping the Colour, the ceremony held in June every year to mark the monarch''s official birthday.</p>'),
(13, 'menu.jpg', 'JPN', 320, 231, 'Menu outside restaurant in Pontocho, Kyoto', '<p>Every city has narrow alleyways that are best avoided, even by the locals. But Kyoto has one alleyway that''s well worth a visit. Pontocho is a long, narrow street only a couple of metres wide that''s crammed with restaurants and bars. There are dozens, if not hundreds of them; and if you''re adventurous enough to wander into even narrower side-alleys, you''ll find a few more.</p><p>Some of the restaurants are very modern, but others seem as though they haven''''t changed since time immemorial. The best way to enjoy an evening''s meal in Kyoto is to perch yourself on a tiny stool at the counter of a restaurant serving o-banzai. It''s hard to describe o-banzai other than as exotic, high-class, home cooking. The ingredients depend on what''s in season, but include a lot of fish, vegetables, tofu, and pork. It doesn''''t matter if you can''t read the menu, because most food is laid out in small dishes on the counter, and served in tiny portions. A delicious, traditional night out.</p>'),
(14, 'monk.jpg', 'JPN', 189, 350, 'Monk begging for alms in Kyoto', '<p>The area in front of Kiyomizu Temple in Kyoto is constantly thronged with tourists. It''s a noisy, lively place. Yet apparently oblivious to all around him was this monk, quietly chanting sutras. From time to time, someone would approach and place an offering in his bowl. His only response was to lift the bowl higher, and then bow deeply, all the while continuing to chant.</p><p>It was December and bitterly cold. Only the thinnest of straw sandals lay between his bare feet and the flagstones.</p>'),
(15, 'ryoanji.jpg', 'JPN', 330, 221, 'Autumn leaves at Ryoanji temple, Kyoto', '<p>Many parts of Japan turn into a blaze of colour in late autumn, as the leaves turn various shades of gold, red, and brown. Ryoanji Temple in the North-West of Kyoto is surrounded by extensive woodland, mainly consisting of maples.</p><p>The temple was founded in 1450, and is famous for its rock garden.</p>'),
(16, 'summerfair.jpg', 'GB', 354, 212, 'All the fun of a summer country fair', '<p>The weather in England is notoriously unpredictable, so it''s a particular treat when the sun manages to time its appearance with a country fair. This Crazy Cottage provided endless hours of fun for small children (and their parents), as they bounced around inside and came down the slides.</p>');
