-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 02, 2007 at 09:33 PM
-- Server version: 5.0.37
-- PHP Version: 5.2.1

-- 
-- Database: `egdwcs3`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(15) NOT NULL,
  `pwd` varchar(40) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `family_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `admin_priv` enum('n','y') NOT NULL default 'n',
  PRIMARY KEY  (`user_id`)
) TYPE=MyISAM ;
