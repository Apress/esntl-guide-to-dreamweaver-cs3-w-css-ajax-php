-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 22, 2007 at 05:42 PM
-- Server version: 5.0.37
-- PHP Version: 5.2.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `egdwcs3`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `authors`
-- 

CREATE TABLE IF NOT EXISTS `authors` (
  `author_id` int(10) unsigned NOT NULL auto_increment,
  `first_name` varchar(30) NOT NULL,
  `family_name` varchar(30) NOT NULL,
  PRIMARY KEY  (`author_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

-- 
-- Dumping data for table `authors`
-- 

INSERT INTO `authors` (`author_id`, `first_name`, `family_name`) VALUES 
(1, 'Woody', 'Allen'),
(2, 'Matsuo', 'Basho'),
(3, 'Jeremy', 'Bentham'),
(4, 'Robert', 'Burns'),
(5, 'Lewis', 'Carroll'),
(6, 'Anton', 'Chekhov'),
(7, 'Winston', 'Churchill'),
(8, 'John', 'Clare'),
(9, 'Samuel Taylor', 'Coleridge'),
(10, 'Leonardo', 'da Vinci'),
(11, 'John', 'Donne'),
(12, 'Albert', 'Einstein'),
(13, 'George', 'Ellis'),
(14, 'Heyward &amp;', 'Gershwin'),
(15, 'HR', 'Haldeman'),
(16, 'Margaret', 'Halsey'),
(17, 'Rick', 'Hansen'),
(18, 'John', 'Keats'),
(19, 'Martin Luther', 'King'),
(20, 'Henry', 'Kissinger'),
(21, '', 'Le Corbusier'),
(22, 'Gary', 'Lineker'),
(23, 'Spike', 'Milligan'),
(24, 'Thomas', 'Moore'),
(25, 'Vladimir', 'Nabokov'),
(26, 'Dorothy', 'Parker'),
(27, 'JB', 'Priestley'),
(28, '', 'Proverb'),
(29, 'Charles', 'Revson'),
(32, 'William', 'Shakespeare'),
(33, 'Percy Bysshe', 'Shelley'),
(34, 'Alfred, Lord', 'Tennyson'),
(36, 'Mark', 'Twain'),
(37, 'Fran&#231;ois', 'Villon'),
(38, '', 'Voltaire'),
(39, 'Horace', 'Walpole'),
(40, 'Orson', 'Welles'),
(41, 'Mae', 'West'),
(42, 'William', 'Wordsworth'),
(43, 'Yogi', 'Berra');

-- --------------------------------------------------------

-- 
-- Table structure for table `quotations`
-- 

CREATE TABLE IF NOT EXISTS `quotations` (
  `quote_id` int(10) unsigned NOT NULL auto_increment,
  `author_id` int(10) unsigned default NULL,
  `quotation` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`quote_id`),
  KEY `author_id` (`author_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

-- 
-- Dumping data for table `quotations`
-- 

INSERT INTO `quotations` (`quote_id`, `author_id`, `quotation`) VALUES 
(1, 17, 'My disability is that I cannot use my legs. My handicap is your negative perception of that disability, and thus of me.'),
(2, 25, 'Life is a great surprise. I do not see why death should not be an even greater one.'),
(3, 23, 'Money couldn''t buy friends, but you got a better class of enemy.'),
(4, 29, 'In the factory we make cosmetics; in the store we sell hope.'),
(5, 36, 'Man is the only animal that blushes. Or needs to.'),
(6, 36, 'Familiarity breeds contempt &#8212; and children.'),
(7, 36, 'Good breeding consists in concealing how much we think of ourselves and how little we think of the other person.'),
(8, 1, 'If it turns out that there is a God, I don''t think that he''s evil. But the worst that you can say about him is that basically, he''s an underachiever.'),
(9, 1, 'I don''t want to achieve immortality through my work... I want to achieve it by not dying.'),
(10, 18, 'A thing of beauty is a joy forever.'),
(11, 18, 'Scenery is fine &#8212; but human nature is finer.'),
(12, 22, 'The nice aspect about football is that, if things go wrong, it''s the manager who gets the blame.'),
(13, 10, 'Iron rusts from disuse; stagnant water loses its purity and in cold weather becomes frozen; even so does inaction sap the vigor of the mind.'),
(14, 21, 'A hundred times I have thought: New York is a catastrophe, and fifty times: it is a beautiful catastrophe.'),
(15, 20, 'Power is the great aphrodisiac.'),
(16, 19, 'Injustice anywhere is a threat to justice everywhere.'),
(17, 7, 'Democracy is the worst form of government except all those other forms that have been tried from time to time.'),
(18, 6, 'Love, friendship, respect do not unite people as much as common hatred for something.'),
(19, 5, 'Everything''s got a moral, if only you can find it.'),
(20, 3, 'The greatest happiness of the greatest number is the foundation of morals and legislation.'),
(21, 26, 'There''s a hell of a distance between wise-cracking and wit. Wit has truth in it; wise-cracking is simply callisthenics with words.'),
(22, 8, 'Summers pleasures they are gone like to visions every one.'),
(23, 2, 'Under the cherry &#8212;\r\nblossom soup,\r\nblossom salad'),
(24, 11, 'No spring, nor summer beauty hath such grace,\r\nAs I have seen in one autumnal face'),
(25, 32, 'Sweet lovers love the spring.'),
(26, 33, 'O, Wind,\r\nIf Winter comes, can Spring be far behind?'),
(27, 34, 'In the spring a young man''s fancy lightly turns to thoughts of love'),
(28, 28, 'It is not spring until you can plant your foot on twelve daisies.'),
(29, 39, 'The way to ensure summer in England is to have it framed and glazed in a comfortable room.'),
(30, 24, '&#8217;Tis the last rose of summer\r\nLeft blooming alone\r\nAll her lovely companions\r\nAre faded and gone'),
(31, 32, 'Shall I compare thee to a summer''s day?\r\nThou art more lovely and temperate'),
(32, 32, 'Now is the winter of our discontent\r\nMade glorious summer by this sun of York'),
(33, 32, 'Blow, blow, thou winter wind,\r\nThou art not so unkind\r\nAs man''s ingratitude'),
(34, 32, 'My age is as a lusty winter, frosty, but kindly.'),
(35, 27, 'The first fall of snow is not only an event, but it is a magical event. You go to bed in one kind of world and wake up to find yourself in another quite different...'),
(36, 9, 'Therefore all seasons shall be sweet to thee.'),
(37, 9, 'The frost performs its secret ministry,\r\nUnhelped by any wind'),
(38, 42, 'And then my heart with pleasure fills,\r\nAnd dances with the daffodills'),
(39, 4, 'Oh, my Luve''s like a red, red rose\r\nThat''s newly sprung in June'),
(40, 18, 'Season of mists and mellow fruitfulness,\r\nClose bosom-friend of the maturing sun'),
(41, 18, 'The coming musk rose, full of dewy wine,\r\nThe murmurous haunt of flies on summer eves'),
(42, 13, 'Snowy, Flowy, Blowy,\r\nShowery, Flowery, Bowery,\r\nHoppy, Croppy, Droppy,\r\nBreezy, Sneezy, Freezy'),
(43, 37, 'Mais o&#249; sont les neiges d''antan? (But where are the snows of yesteryear?)'),
(44, 14, 'Summer time an'' the livin'' is easy,\r\nFish are jumpin'' and the cotton is high'),
(45, 12, 'I never think of the future. It comes soon enough.'),
(46, 16, 'The English never smash in a face. They merely refrain from asking it to dinner.'),
(47, 15, 'Once the toothpaste is out of the tube, it is awfully hard to get back in.'),
(48, 38, 'Le sens commun est fort rare. (Common sense is not so common.)'),
(49, 40, 'I hate television. I hate it as much as peanuts. But I can''t stop eating peanuts.'),
(50, 41, 'I always say, keep a diary and some day it''ll keep you.');
