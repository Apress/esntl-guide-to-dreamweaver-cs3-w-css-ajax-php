<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Check site root support</title>
<style type="text/css">
body {
	font-family:Arial, Helvetica, sans-serif;
	font-size:85%;
	}
</style>
</head>

<body>
<h1>Support for site-root-relative links</h1>
<ul>
  <li><strong>Virtual:</strong> 
    <?php
echo (function_exists('virtual')) ? 'supported' : 'not supported';
?>
  </li>
  <li><strong>$_SERVER['DOCUMENT_ROOT']: </strong>
  <?php echo (isset($_SERVER['DOCUMENT_ROOT'])) ? $_SERVER['DOCUMENT_ROOT'] : 'not supported'; ?></li>
</ul>
</body>
</html>
