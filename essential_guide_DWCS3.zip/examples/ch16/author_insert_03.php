<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$var1_checkAuthor = "none";
if (isset($_POST['first_name'])) {
  $var1_checkAuthor = $_POST['first_name'];
}
$var2_checkAuthor = "none";
if (isset($_POST['family_name'])) {
  $var2_checkAuthor = $_POST['family_name'];
}
mysql_select_db($database_connAdmin, $connAdmin);
$query_checkAuthor = sprintf("SELECT * FROM authors WHERE authors.first_name = %s AND authors.family_name = %s", GetSQLValueString($var1_checkAuthor, "text"),GetSQLValueString($var2_checkAuthor, "text"));
$checkAuthor = mysql_query($query_checkAuthor, $connAdmin) or die(mysql_error());
$row_checkAuthor = mysql_fetch_assoc($checkAuthor);
$totalRows_checkAuthor = mysql_num_rows($checkAuthor);

// assume no match has been found
$alreadyRegistered = false;

// check whether recordset found any matches
if ($totalRows_checkAuthor > 0) {
  // if found, reset $alreadyRegistered
  $alreadyRegistered = true;
  }
else {
  // go ahead with the Insert Record server behavior
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO authors (first_name, family_name) VALUES (%s, %s)",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($insertSQL, $connAdmin) or die(mysql_error());

  $insertGoTo = "author_list.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert new author</title>
<link href="../styles/form.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert new author</h1>
<?php
if ($_POST && $alreadyRegistered) {
  echo '<p class="warning">'.$_POST['first_name'].' '.$_POST['family_name'].' is already registered</p>';
  }
?>
<form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
  <p>
    <label for="first_name">First name:</label>
    <input name="first_name" type="text" class="textInput" id="first_name" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <input name="family_name" type="text" class="textInput" id="family_name" />
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert author" />
  </p>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p><a href="author_list.php">List authors</a></p>
</body>
</html>
<?php
mysql_free_result($checkAuthor);
?>
