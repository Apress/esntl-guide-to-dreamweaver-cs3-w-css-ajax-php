<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connAdmin, $connAdmin);
$query_listAuthors = "SELECT authors.author_id, CONCAT_WS(' ', authors.first_name, authors.family_name) AS author FROM authors ORDER BY authors.family_name, authors.first_name";
$listAuthors = mysql_query($query_listAuthors, $connAdmin) or die(mysql_error());
$row_listAuthors = mysql_fetch_assoc($listAuthors);
$totalRows_listAuthors = mysql_num_rows($listAuthors);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert new quotation</title>
<link href="../styles/form.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert new quotation</h1>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="quotation">Quotation:</label>
    <textarea name="quotation" id="quotation" cols="45" rows="5"></textarea>
  </p>
  <p>
    <label for="author_id">Author:</label>
    <select name="author_id" id="author_id">
      <option value="">Not registered</option>
      <?php
do {  
?>
      <option value="<?php echo $row_listAuthors['author_id']?>"><?php echo $row_listAuthors['author']?></option>
      <?php
} while ($row_listAuthors = mysql_fetch_assoc($listAuthors));
  $rows = mysql_num_rows($listAuthors);
  if($rows > 0) {
      mysql_data_seek($listAuthors, 0);
	  $row_listAuthors = mysql_fetch_assoc($listAuthors);
  }
?>
        </select>
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert quotation" />
  </p>
</form>
<p><a href="quote_list.php">List quotations</a></p>
</body>
</html>
<?php
mysql_free_result($listAuthors);
?>
