<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert new quotation</title>
<link href="../styles/form.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert new quotation</h1>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="quotation">Quotation:</label>
    <textarea name="quotation" id="quotation" cols="45" rows="5"></textarea>
  </p>
  <p>
    <label for="author_id">Author:</label>
    <select name="author_id" id="author_id">
    </select>
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert quotation" />
  </p>
</form>
<p><a href="quote_list.php">List quotations</a></p>
</body>
</html>
