<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}


$colname_getAuthor = "-1";
if (isset($_GET['author_id'])) {
  $colname_getAuthor = $_GET['author_id'];
}
mysql_select_db($database_connAdmin, $connAdmin);
$query_getAuthor = sprintf("SELECT * FROM authors WHERE author_id = %s", GetSQLValueString($colname_getAuthor, "int"));
$getAuthor = mysql_query($query_getAuthor, $connAdmin) or die(mysql_error());
$row_getAuthor = mysql_fetch_assoc($getAuthor);
$totalRows_getAuthor = mysql_num_rows($getAuthor);

$var1_checkForeign = "-1";
if (isset($_GET['author_id'])) {
  $var1_checkForeign = $_GET['author_id'];
}
mysql_select_db($database_connAdmin, $connAdmin);
$query_checkForeign = sprintf("SELECT authors.first_name, authors.family_name, quotations.author_id, quotations.quotation FROM authors, quotations WHERE quotations.author_id = %s AND quotations.author_id = authors.author_id", GetSQLValueString($var1_checkForeign, "int"));
$checkForeign = mysql_query($query_checkForeign, $connAdmin) or die(mysql_error());
$row_checkForeign = mysql_fetch_assoc($checkForeign);
$totalRows_checkForeign = mysql_num_rows($checkForeign);

// assume no match has been found
$recordsExist = false;

// check whether recordset found any matches
if ($totalRows_checkForeign > 0) {
  // if found, reset $recordsExist
  $recordsExist = true;
  }
else {
  // go ahead with the server behavior
if ((isset($_POST['author_id'])) && ($_POST['author_id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM authors WHERE author_id=%s",
                       GetSQLValueString($_POST['author_id'], "int"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($deleteSQL, $connAdmin) or die(mysql_error());

  $deleteGoTo = "author_list.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Delete author</title>
<link href="../styles/form.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Delete author</h1>
    <?php
if ($recordsExist) {
  echo '<p class="warning">'.$row_checkForeign['first_name'].' '.$row_checkForeign['family_name'].' has the following dependent records. Can\'t be deleted.</p>'; ?>
  <!-- To add this display, amend the checkForeign recordset to retrieve the quotation column from
       the quotations table. Then do the following (all in Code view):
       1. Add closing and opening PHP tags between the end of the previous line and the curly brace.
          This creates a space for XHTML.
       2. Insert a pair of <ul> tags with a single pair of <li> tags in between.
       3. Place the insertion point between the <li> tags.
       4. In the Bindings panel, highlight quotation in the checkForeign recordset and click Insert.
       5. Select the <li> tags and the intervening PHP code.
       6. Apply a Repeat Region, selecting the checkForeign recordset, and displaying all records. -->
<ul>
      <?php do { ?>
      <li><?php echo $row_checkForeign['quotation']; ?></li>
        <?php } while ($row_checkForeign = mysql_fetch_assoc($checkForeign)); ?></ul>
    <?php
  }
else {
?>
<p class="warning">Please confirm that you want to delete the following record. This operation cannot be undone.</p>
<form id="form1" name="form1" method="POST">
  <p>
    <label for="first_name">First name:</label>
    <input name="first_name" type="text" class="textInput" id="first_name" value="<?php echo $row_getAuthor['first_name']; ?>" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <input name="family_name" type="text" class="textInput" id="family_name" value="<?php echo $row_getAuthor['family_name']; ?>" />
  </p>
  <p>
    <input type="submit" name="delete" id="delete" value="Delete author" />
    <input name="author_id" type="hidden" id="author_id" value="<?php echo $row_getAuthor['author_id']; ?>" />
  </p>
  
  
</form>
<?php } ?>
<p><a href="author_list.php">List authors</a></p>
</body>
</html>
<?php
mysql_free_result($getAuthor);

mysql_free_result($checkForeign);
?>
