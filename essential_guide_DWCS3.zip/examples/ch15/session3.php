<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Session test 3</title>
</head>

<body>
<?php
// check whether session variable is set
if (isset($_SESSION['name'])) {
  // if set, greet by name
  echo 'Hi, '.$_SESSION['name'].'. See, I remembered your name! Sessions are working.<br />';
  // unset session variable
  unset($_SESSION['name']);
  // end session
  session_destroy();
  echo '<a href="session2.php">Page 2</a>';
  }
else {
  // display if not recognized
  echo 'Sorry, I don\'t know you.<br />';
  echo '<a href="session1.php">Login</a>';
  }
?>
</body>
</html>
