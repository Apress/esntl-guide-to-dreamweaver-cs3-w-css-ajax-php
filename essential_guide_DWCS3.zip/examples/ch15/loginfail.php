<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login failed</title>
</head>

<body>
<h1>Sorry!</h1>
<p>There was a problem with your username or password. <a href="login.php">Return to login page</a>.</p>
</body>
</html>
