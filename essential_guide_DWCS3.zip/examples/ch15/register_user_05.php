<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// *** Check if username exists
$error = array();
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  // check name
  if (empty($_POST['first_name']) || empty($_POST['family_name'])) {
    $error['name'] = 'Please enter both first name and family name';
	}
  // set a flag that assumes the password is OK
  $pwdOK = true;
  // trim leading and trailing white space
  $_POST['pwd'] = trim($_POST['pwd']);
  // if less than 6 characters, create alert and set flag to false
  if (strlen($_POST['pwd']) < 6) {
    $error['pwd_length'] = 'Your password must be at least 6 characters';
    $pwdOK = false;
    }
  // if no match, create alert and set flag to false
  if ($_POST['pwd'] != trim($_POST['conf_pwd'])) {
    $error['pwd'] = 'Your passwords don\'t match';
    $pwdOK = false;
    }
  // if password OK, encrypt it
  if ($pwdOK) {
    $_POST['pwd'] = sha1($_POST['pwd']);
    }
  // regex to identify illegal characters in email address
  $checkEmail = '/^[^@]+@[^\s\r\n\'";,@%]+$/';
  if (!preg_match($checkEmail, trim($_POST['email']))) {
    $error['email'] = 'Please enter a valid email address';
    }
  // check username
  $_POST['username'] = trim($_POST['username']);
  $loginUsername = $_POST['username'];
  if (strlen($loginUsername) < 6) {
    $error['length'] = 'Please select a username that contains at least 6 characters';
    }
  $LoginRS__query = sprintf("SELECT username FROM users WHERE username=%s", GetSQLValueString($loginUsername, "text"));
  mysql_select_db($database_connAdmin, $connAdmin);
  $LoginRS=mysql_query($LoginRS__query, $connAdmin) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
  $error['username'] = "$loginUsername is already in use. Please choose a different username.";
  }
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if (!$error) {
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO users (first_name, family_name, email, username, pwd, admin_priv) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['pwd'], "text"),
                       GetSQLValueString($_POST['admin_priv'], "text"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($insertSQL, $connAdmin) or die(mysql_error());
}
// if the record has been inserted, clear the $_POST array
$_POST = array();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register user</title>
</head>

<body>
<h1>Register user</h1>
<?php
if ($error) {
  echo '<ul>';
  foreach ($error as $alert) {
    echo "<li class='warning'>$alert</li>\n";
	}
  echo '</ul>';
  // remove escape characters from POST array
  if (get_magic_quotes_gpc()) {
    function stripslashes_deep($value) {
      $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
      return $value;
      }
    $_POST = array_map('stripslashes_deep', $_POST);
    }
  }
?>
  <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
    <table align="center">
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">First name:</td>
        <td><input type="text" name="first_name" value="<?php if (isset($_POST['first_name'])) {
echo htmlentities($_POST['first_name']);} ?>" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Family name:</td>
        <td><input type="text" name="family_name" value="<?php if (isset($_POST['family_name'])) {
echo htmlentities($_POST['family_name']);} ?>" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Email:</td>
        <td><input type="text" name="email" value="<?php if (isset($_POST['email'])) {
echo htmlentities($_POST['email']);} ?>" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Username:</td>
        <td><input type="text" name="username" value="<?php if (isset($_POST['username'])) {
echo htmlentities($_POST['username']);} ?>" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Password:</td>
        <td><input type="password" name="pwd" value="" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Confirm password:</td>
        <td valign="baseline"><input type="password" name="conf_pwd" id="conf_pwd" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Administrator:</td>
        <td valign="baseline"><table>
            <tr>
              <td><input <?php if ($_POST && !(strcmp($_POST['admin_priv'],"y"))) {echo "checked=\"checked\"";} ?> type="radio" name="admin_priv" value="y" />              
              Yes</td>
          </tr>
            <tr>
              <td><input <?php if (($_POST && !(strcmp($_POST['admin_priv'],"n"))) || !$_POST) {echo "checked=\"checked\"";} ?> type="radio" name="admin_priv" value="n" />                
              No</td>
            </tr>
        </table></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">&nbsp;</td>
        <td><input type="submit" value="Insert record" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1" />
  </form>
</body>
</html>
