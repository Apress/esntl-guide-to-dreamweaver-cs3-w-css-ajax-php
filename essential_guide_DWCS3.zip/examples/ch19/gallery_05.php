<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>East-West Seasons Gallery</title>
<script src="../../SpryAssets/xpath.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryEffects.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var dsGalleries = new Spry.Data.XMLDataSet("../../examples/ch19/galleries.xml", "galleries/gallery");
var dsPhotos = new Spry.Data.XMLDataSet("{dsGalleries::@file}", "gallery/photo");
function MM_effectHighlight(targetElement, duration, startColor, endColor, restoreColor, toggle)
{
	Spry.Effect.DoHighlight(targetElement, {duration: duration, from: startColor, to: endColor, restoreColor: restoreColor, toggle: toggle});
}
//-->
</script>
<link href="../styles/gallery.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper">
  <div id="header"><img src="../../images/tulips_top.jpg" alt="East-West Seasons" width="720" height="100" /></div>
  <div spry:region="dsGalleries" id="select">
    <label for="chooseGallery"><strong>Select gallery:</strong> </label>
    <select name="chooseGallery" spry:repeatchildren="dsGalleries" onchange="dsGalleries.setCurrentRow(this.value)" id="chooseGallery">
      <option value="{ds_RowID}">{name}</option>
    </select>
  </div>
  <div spry:region="dsPhotos" id="thumbs"><span spry:repeat="dsPhotos"><img src="../../images/gallery/thumbs/{file}" alt="thumbnail" width="80" height="54" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#FFFF33', '#FFFF33', false)" onmouseout="MM_effectHighlight(this, 1000, '#FFFF33', '#FFFFFF', '#ffffff', false)" spry:setrow="dsPhotos" /></span></div>
  <div spry:detailregion="dsPhotos" id="mainPic">
    <p><img src="../../images/gallery/{file}" alt="{caption}" height="{file/@height}" width="{file/@width}" /><br />
      {caption}</p>
  </div>
  <div spry:detailregion="dsPhotos" id="description">{description}</div>
</div>
</body>
</html>
