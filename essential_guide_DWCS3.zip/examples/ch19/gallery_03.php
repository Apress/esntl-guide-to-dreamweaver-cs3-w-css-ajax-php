<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>East-West Seasons Gallery</title>
<link href="../styles/gallery.css" rel="stylesheet" type="text/css" />
<script src="../../SpryAssets/xpath.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var dsGalleries = new Spry.Data.XMLDataSet("galleries.xml", "galleries/gallery");
var dsPhotos = new Spry.Data.XMLDataSet("england.xml", "gallery/photo");
dsPhotos.setColumnType("file/@height", "number");
dsPhotos.setColumnType("file/@width", "number");
//-->
</script>
</head>

<body>
<div id="wrapper">
  <div id="header"><img src="../../images/tulips_top.jpg" alt="East-West Seasons" /></div>
  <div id="select" spry:region="dsGalleries">
    <label for="chooseGallery">Select gallery: </label><select name="chooseGallery" spry:repeatchildren="dsGalleries" id="chooseGallery">
      <option value="{@file}">{name}</option>
    </select>
  </div>
  <div id="thumbs" spry:region="dsPhotos"><span spry:repeat="dsPhotos"><img src="../../images/gallery/thumbs/{file}" alt="thumbnail" width="80" height="54" spry:setrow="dsPhotos" /></span></div>
  <div id="mainPic" spry:detailregion="dsPhotos">
    <p><img src="../../images/gallery/{file}" alt="{caption}" width="{file/@width}" height="{file/@height}" /><br />
    {caption}</p>
  </div>
  <div id="description" spry:detailregion="dsPhotos">{description}</div>
</div>
</body>
</html>
