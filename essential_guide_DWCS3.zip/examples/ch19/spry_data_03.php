<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Spry data example</title>
<script src="../../SpryAssets/xpath.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var dsEngland = new Spry.Data.XMLDataSet("../../examples/ch19/england.xml", "gallery/photo",{sortOnLoad:"file/@width",sortOrderOnLoad:"descending"});
dsEngland.setColumnType("file/@height", "number");
dsEngland.setColumnType("file/@width", "number");
//-->
</script>
<link href="../../examples/styles/spry_table.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div spry:region="dsEngland">
  <dl spry:repeatchildren="dsEngland">
    <dt>{file}</dt>
    <dd><span spry:setrow="dsEngland" spry:hover="hover" spry:select="selected">{caption}</span></dd>
  </dl>
</div>
<div spry:detailregion="dsEngland">{description}</div>
</body>
</html>
