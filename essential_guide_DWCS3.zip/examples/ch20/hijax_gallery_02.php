<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$var1_getThumbs = "GB";
if (isset($_GET['category'])) {
  $var1_getThumbs = $_GET['category'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getThumbs = sprintf("SELECT ch20_gallery.photo_id, ch20_gallery.filename FROM ch20_gallery WHERE ch20_gallery.category = %s", GetSQLValueString($var1_getThumbs, "text"));
$getThumbs = mysql_query($query_getThumbs, $connQuery) or die(mysql_error());
$row_getThumbs = mysql_fetch_assoc($getThumbs);
$totalRows_getThumbs = mysql_num_rows($getThumbs);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>East-West Seasons Gallery</title>
<link href="../styles/gallery.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper">
  <div id="header"><img src="../../images/tulips_top.jpg" alt="East-West Seasons" /></div>
  <div id="select">
    <form id="form1" name="form1" method="get" action="">
      <label for="category">Select gallery: </label>
      <select name="category" id="category">
        <option value="GB">England</option>
        <option value="JPN">Japan</option>
                  </select>
      <input type="submit" name="go" id="go" value="Go" />
    </form>
  </div>
  <div id="thumbs"> 
    <?php do { ?>
      <a href="hijax_gallery.php?photo_id=<?php echo $row_getThumbs['photo_id']; ?>"><img src="../../images/gallery/thumbs/<?php echo $row_getThumbs['filename']; ?>" alt="thumbnail" width="80" height="54" /></a>
      <?php } while ($row_getThumbs = mysql_fetch_assoc($getThumbs)); ?> </div>
  <div>Content for  id "mainPic" Goes Here</div>
  <div id="description">Content for  id "description" Goes Here</div>
</div>
</body>
</html>
<?php
mysql_free_result($getThumbs);
?>