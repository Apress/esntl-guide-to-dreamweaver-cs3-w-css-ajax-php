<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>East-West Seasons Gallery</title>
<link href="../styles/gallery.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper">
  <div id="header"><img src="../../images/tulips_top.jpg" alt="East-West Seasons" /></div>
  <div id="select">
    <form id="form1" name="form1" method="get" action="">
      <label for="category">Select gallery: </label>
      <select name="category" id="category">
        <option value="GB">England</option>
        <option value="JPN">Japan</option>
                  </select>
      <input type="submit" name="go" id="go" value="Go" />
    </form>
  </div>
  <div id="thumbs">Content for  id "thumbs" Goes Here</div>
  <div id="mainPic">Content for  id "mainPic" Goes Here</div>
  <div id="description">Content for  id "description" Goes Here</div>
</div>
</body>
</html>
