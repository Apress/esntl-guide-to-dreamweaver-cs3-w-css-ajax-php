<?php
// URL to file that generates local dynamic XML source
$url = 'http://egdwcs3/workfiles/ch20/japan_manual.php';
// Get the XML and store it in a variable
$xml = file_get_contents($url);
// Set the name of the file to write the XML to
$xmlfile = 'japan_proxy_manual.xml';
// Include the writeToFile() function and call it
require('../includes/write_file.inc.php');
writeToFile($xml, $xmlfile);
?>
