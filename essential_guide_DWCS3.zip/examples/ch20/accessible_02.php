<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connQuery, $connQuery);
$query_getCaptions = "SELECT photo_id, filename, caption FROM ch20_gallery WHERE category = 'GB'";
$getCaptions = mysql_query($query_getCaptions, $connQuery) or die(mysql_error());
$row_getCaptions = mysql_fetch_assoc($getCaptions);
$totalRows_getCaptions = mysql_num_rows($getCaptions);

$colname_getDescription = "2";
if (isset($_GET['photo_id'])) {
  $colname_getDescription = $_GET['photo_id'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getDescription = sprintf("SELECT `description` FROM ch20_gallery WHERE photo_id = %s", GetSQLValueString($colname_getDescription, "int"));
$getDescription = mysql_query($query_getDescription, $connQuery) or die(mysql_error());
$row_getDescription = mysql_fetch_assoc($getDescription);
$totalRows_getDescription = mysql_num_rows($getDescription);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Accessible Spry example</title>
<script src="../../SpryAssets/xpath.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var dsPhotos = new Spry.Data.XMLDataSet("../../examples/ch19/england.xml", "gallery/photo");
//-->
</script>
</head>

<body>
<table>
  <tr>
    <th scope="col">Filename</th>
    <th scope="col">Caption</th>
  </tr>
  <?php $i =0; ?>
  <?php do { ?>
    <tr>
      <td><?php echo $row_getCaptions['filename']; ?></td>
      <td><a href="accessible.php?photo_id=<?php echo $row_getCaptions['photo_id']; ?>" onclick="dsPhotos.setCurrentRowNumber(<?php echo $i++; ?>); return false"><?php echo $row_getCaptions['caption']; ?></a></td>
    </tr>
    <?php } while ($row_getCaptions = mysql_fetch_assoc($getCaptions)); ?>
</table>
<div id="description" spry:detailregion="dsPhotos" spry:content="{description}"><?php echo $row_getDescription['description']; ?></div>
</body>
</html>
<?php
mysql_free_result($getCaptions);

mysql_free_result($getDescription);
?>
