<?php
$url = '../../workfiles/ch20/japan_manual.php';
// Make sure the remote feed is accessible, then fetch it
if (file_exists($url) && is_readable($url)) {
  $remote = file_get_contents($url);
  // Send an XML header and display the feed
  header('Content-Type: text/xml');
  echo $remote;
  }
else {
  echo "Cannot open remote file at $url";
  }
?>