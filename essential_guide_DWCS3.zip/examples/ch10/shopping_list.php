<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Foreach loop - shopping list</title>
<style type="text/css">
body {
	font-family:Arial, Helvetica, sans-serif;
	}
h1 {
	font-size:150%;
	}
p {
	font-size:85%;
	width:650px;
	}
</style>
</head>

<body>
<h1>Foreach loop</h1>
<p>The foreach loop is used exclusively with arrays. In its basic form, the loop iterates through each item in the array assigning it to a temporary variable. In this example, it loops through the $shopping_list array, assigning each element in turn to $item and displaying it with echo.</p>
<p>Switch to Code view in Dreamweaver to see the PHP code.</p>
<?php
$shopping_list = array('wine', 'fish', 'bread', 'grapes', 'cheese');
foreach ($shopping_list as $item) {
  echo $item.'<br />';
  }
?>
</body>
</html>
