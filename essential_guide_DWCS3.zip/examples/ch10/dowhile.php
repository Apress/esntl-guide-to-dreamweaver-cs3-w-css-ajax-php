<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Do... while loop</title>
<style type="text/css">
body {
	font-family:Arial, Helvetica, sans-serif;
	}
h1 {
	font-size:150%;
	}
p {
	font-size:85%;
	width:650px;
	}
</style>
</head>

<body>
<h1>Do... while loop</h1>
<p>A do... while loop always runs at least once because the condition isn't evaluated until the while clause at the end of the loop. In this example the counter ($i) is set to 1000 outside the loop, and increased by 1 each time the loop runs. So it displays 1000 and increases the counter to 1001. However, the condition returns true only if the counter is less than or equal to 100. Since the counter is already over that level, the condition is false and the loop stops.</p>
<p>Switch to Code view in Dreamweaver to see the PHP code.</p>
  <?php
$i = 1000; // set counter
do {
  echo $i.'<br />';
  $i++; // increase counter by 1
  } while ($i <= 100);
?>
</body>
</html>
