<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact form</title>
<link href="../styles/contact.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Contact Us</h1>
<p>We welcome feedback from visitors to our site. Please use the following form to let us know what you think about it.</p>
<form action="" method="post" name="form1" id="form1">
    <fieldset>
    <legend>Your details</legend>
    <p>
        <label for="name">Name:</label>
        <input name="name" type="text" class="textInput" id="name" value="" />
    </p>
    <p>
        <label for="email">Email:</label>
        <input name="email" type="text" class="textInput" id="email" value="" />
    </p>
    </fieldset>
    <fieldset>
    <legend>Your views</legend>
    <p>
        <label for="comments">Comments:</label>
        <textarea name="comments" cols="45" rows="6" id="comments"></textarea>
    </p>
    <p><strong>What aspects of London most interest you?</strong></p>
    <div class="chkRad">
        <p>
            <input name="interestsClassical" type="checkbox" id="interestsClassical" value="Classical concerts" />
            <label for="interestsClassical">Classical concerts</label>
        </p>
        <p>
            <input type="checkbox" name="interestsRock" id="interestsRock" />
            <label for="interestsRock">Rock/pop events</label>
        </p>
        <p>
            <input type="checkbox" name="interestsDrama" id="interestsDrama" />
            <label for="interestsDrama">Drama</label>
        </p>
    </div>
    <div class="chkRad">
        <p>
            <input type="checkbox" name="interestsWalks" id="interestsWalks" />
            <label for="interestsWalks">Guided walks</label>
        </p>
        <p>
            <input type="checkbox" name="interestsArt" id="interestsArt" />
            <label for="interestsArt">Art</label>
        </p>
    </div>
    <p class="clearIt">
        <label for="visited">Have you ever been to London?</label>
        <select name="visited" id="visited">
            <option selected="selected">-- Select one --</option>
            <option value="Never">Never</option>
            <option value="Once or twice">Once or twice</option>
            <option value="Not yearly">Less than once a year</option>
            <option value="Yearly">I go every year</option>
            <option value="Monthly">I go there most months</option>
            <option value="Local">I live/work there</option>
        </select>
    </p>
    <p>
        <label for="views">What are your impressions of London?</label>
        <select name="views" size="6" multiple="multiple" id="views">
            <option value="Vibrant">It's a vibrant, exciting city</option>
            <option value="Historic/cultural">Full of history and culture</option>
            <option value="Good food">A great place to eat</option>
            <option value="Boring">Boring, nothing to do</option>
            <option value="Awful food">The food's awful</option>
            <option value="Dirty/overcrowded">It's overcrowded and dirty</option>
                                        </select>
    </p>
    <p><strong>Would you like to get regular details of events in London?</strong></p>
    <div class="chkRad">
        <p>
            <input type="radio" name="radio" id="subscribe" value="subscribe" />
            <label for="subscribe">Yes </label>
            <input type="radio" name="radio" id="subscribeNo" value="subscribeNo" />
            <label for="subscribeNo">No</label>
        </p>
    </div>
    <p class="clearIt">
        <input type="submit" name="send" id="send" value="Send comments" />
    </p>
    </fieldset>
</form>
</body>
</html>
