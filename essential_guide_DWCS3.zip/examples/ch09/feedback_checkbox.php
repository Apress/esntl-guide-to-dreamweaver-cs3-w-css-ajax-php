<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact form</title>
<link href="../styles/contact.css" rel="stylesheet" type="text/css" /></head>

<body>
<h1>Contact Us</h1>
<p>We welcome feedback from visitors to our site. Please use the following form to let us know what you think about it.</p>
<form action="" method="post" name="form1" id="form1">
    <p>
        <label for="name">Name:</label>
        <input name="name" type="text" class="textInput" id="name" />
    </p>
    <p>
        <label for="email">Email:</label>
        <input name="email" type="text" class="textInput" id="email" />
    </p>
    <p>
        <label for="comments">Comments:</label>
        <textarea name="comments" id="comments" cols="45" rows="5"></textarea>
    </p>
    <p><strong>What aspects of London most interest you?</strong></p>
    <div class="chkRad">
        <p>
            <input name="interests[]" type="checkbox" id="interestsClassical" value="Classical concerts" />
            <label for="interestsClassical">Classical concerts</label>
        </p>
        <p>
            <input name="interests[]" type="checkbox" id="interestsRock" value="Rock/pop" />
            <label for="interestsRock">Rock/pop events</label>
        </p>
        <p>
            <input name="interests[]" type="checkbox" id="interestsDrama" value="Drama" />
            <label for="interestsDrama">Drama</label>
        </p>
    </div>
    <div class="chkRad">
        <p>
            <input name="interests[]" type="checkbox" id="interestsWalks" value="Guided walks" />
            <label for="interestsWalks">Guided walks</label>
        </p>
        <p>
            <input name="interests[]" type="checkbox" id="interestsArt" value="Art" />
            <label for="interestsArt">Art</label>
        </p>
    </div>
    <p class="clearIt">
        <input type="submit" name="send" id="send" value="Send comments" />
    </p>
</form>
<pre>
<?php if ($_POST) {print_r($_POST);} ?>
</pre>
</body>
</html>
