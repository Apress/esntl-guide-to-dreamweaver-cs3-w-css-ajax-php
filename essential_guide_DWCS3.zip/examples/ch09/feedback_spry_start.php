<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact form</title>
<link href="../styles/contact.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Contact Us</h1>
<p>We welcome feedback from visitors to our site. Please use the following form to let us know what you think about it.</p>
<form action="" method="post" name="form1" id="form1">
    <fieldset>
    <legend>Your details</legend>
    <p>
        <label for="name">Name:</label>
        <input name="name" type="text" class="textInput" id="name" />
    </p>
<p>
        <label for="email">Email:</label>
        <input name="email" type="text" class="textInput" id="email" />
    </p>
    </fieldset>
    <fieldset>
    <legend>Your views</legend>
    <p>
        <label for="comments">Comments:</label>
        <textarea name="comments" id="comments" cols="45" rows="5"></textarea>
    </p>
    <p><strong>What aspects of London most interest you?</strong></p>
    <div id="sprycheckbox1">
    <div class="checkboxMinSelectionsMsg">Minimum number of selections not met.</div>
    <div class="chkRad">
        <p>
            <input name="interests[]" type="checkbox"  id="interestsClassical" value="Classical concerts" />
            <label for="interestsClassical">Classical concerts</label>
        </p>
        <p>
            <input name="interests[]" type="checkbox" id="interestsRock" value="Rock/pop" />
            <label for="interestsRock">Rock/pop events</label>
        </p>
        <p>
            <input name="interests[]" type="checkbox" id="interestsDrama" value="Drama" />
            <label for="interestsDrama">Drama</label>
        </p>
    </div>
    <div class="chkRad">
        <p>
            <input name="interests[]" type="checkbox" id="interestsWalks" value="Guided walks" />
            <label for="interestsWalks">Guided walks</label>
        </p>
        <p>
            <input name="interests[]" type="checkbox" id="interestsArt" value="Art" />
            <label for="interestsArt">Art</label>
        </p>
    </div>
    </div>
  <p class="clearIt">
        <label for="visited">How often have you been to London?</label>
        <select name="visited" id="visited">
            <option value="0" selected="selected">-- Select one --</option>
            <option value="Never">Never been</option>
            <option value="1-2 times">Once or twice</option>
            <option value="Not yearly">Less than once a year</option>
            <option value="Yearly">I go most years</option>
            <option value="Live/work">I live/work there</option>
        </select>
    </p>
    <p>
        <label for="views">What image do you have of London?</label>
        <select name="views[]" size="6" multiple="multiple" id="views">
            <option value="Vibrant/exciting">A vibrant, exciting city</option>
            <option value="Good food">A great place to eat</option>
            <option value="Good transport">Convenient transport</option>
            <option value="Dull">Dull, dull, dull</option>
            <option value="Bad food">The food's rotten</option>
            <option value="Transport nightmare">A transport nightmare</option>
                                        </select>
    </p>
    <p><strong>Would you like to receive regular details of events in London?</strong></p>
    <div class="chkRad">
        <p>
            <input type="radio" name="subscribe" id="subscribeYes" value="y" />
            <label for="subscribeYes">Yes</label> 
            <input name="subscribe" type="radio" id="subscribeNo" value="n" checked="checked" />
            <label for="subscribeNo">No</label>
        </p>
    </div>
    <p>&nbsp;</p>
    <p class="clearIt">
        <input type="submit" name="send" id="send" value="Send comments" />
    </p>
    </fieldset>
</form>
<pre>
<?php if ($_POST) {print_r($_POST);} ?>
</pre>
</body>
</html>
