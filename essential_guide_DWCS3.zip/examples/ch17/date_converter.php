<?php
$months = array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
$now = getdate();
if ($_POST) {
  $m = $_POST['month'];
  $d = trim($_POST['day']);
  $y = trim($_POST['year']);
  if (empty($d) || empty($y)) {
    $error = 'Please fill in all fields';
    }
  elseif (!is_numeric($d) || !is_numeric($y)) {
    $error = 'Please use numbers only';
    }
  elseif (($d <1 || $d > 31) || ($y < 1000 || $y > 9999)) {
    $error = 'Please use numbers within the correct range';
    }
  elseif (!checkdate($m,$d,$y)) {
    $error = 'You have used an invalid date';
    }
  else {
    $d = $d < 10 ? '0'.$d : $d;
    $mysqlFormat = "$y-$m-$d";
    }
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Convert date to MySQL format</title>
</head>

<body>
<form id="convert" name="convert" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <p>
    <label for="select">Month:</label>
    <select name="month" id="month">
      <?php for ($i=1;$i<=12;$i++) { ?>
      <option value="<?php echo $i < 10 ? '0'.$i : $i; ?>"
      <?php if ($i == $now['mon']) {
        echo ' selected="selected"'; } ?>><?php echo $months[$i-1]; ?>
      </option>
      <?php } ?>
    </select> 
    <label for="day">Date:</label>
    <input name="day" type="text" id="day" size="2" maxlength="2" />
    <label for="year">Year:</label>
    <input name="year" type="text" id="year" size="4" maxlength="4" />
  </p>
  <p>
    <input type="submit" name="Submit" value="Convert to MySQL format" />
  </p>
</form>
<?php
if ($_POST) { 
  echo '<p>';
  if (isset($error)) {
    echo $error;
    }
  elseif (isset($mysqlFormat)) {
    echo $mysqlFormat;
    }
  echo '</p>';
  }
?>
</body>
</html>
