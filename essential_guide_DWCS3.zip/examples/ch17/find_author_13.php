<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_getAuthors = "-1";
if (isset($_POST['first_name'])) {
  $colname_getAuthors = $_POST['first_name'];
}
$colname2_getAuthors = "-1";
if (isset($_POST['family_name'])) {
  $colname2_getAuthors = $_POST['family_name'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getAuthors = sprintf("SELECT first_name, family_name FROM authors WHERE first_name LIKE %s AND family_name LIKE %s ORDER BY family_name ASC", GetSQLValueString($colname_getAuthors . "%", "text"),GetSQLValueString($colname2_getAuthors . "%", "text"));
$getAuthors = mysql_query($query_getAuthors, $connQuery) or die(mysql_error());
$row_getAuthors = mysql_fetch_assoc($getAuthors);
$totalRows_getAuthors = mysql_num_rows($getAuthors);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Find an author by name beginning with</title>
</head>

<body>
<h1>Find that author!</h1>
<p><strong>Search for names beginning with</strong></p>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="first_name">First name:</label>
    <input type="text" name="first_name" id="first_name" />
    <label for="family_name">Family name:</label>
    <input type="text" name="family_name" id="family_name" />
  </p>
  <p>
    <input type="submit" name="search" id="search" value="Search" />
  </p>
</form>

<?php if (array_key_exists('search', $_POST) && $totalRows_getAuthors == 0) { // Show if recordset empty ?>
  <p><strong>No results found</strong></p>
<?php } // Show if recordset empty ?>
<?php if (array_key_exists('search', $_POST)) { ?>
<p><strong>SQL query used:</strong> <?php echo $query_getAuthors; }?></p>
<table width="400">
  <?php do { ?>
    <tr>
      <td><?php echo $row_getAuthors['first_name']; ?> <?php echo $row_getAuthors['family_name']; ?></td>
    </tr>
    <?php } while ($row_getAuthors = mysql_fetch_assoc($getAuthors)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($getAuthors);
?>
