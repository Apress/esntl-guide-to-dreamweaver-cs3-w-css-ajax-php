<?php
//XMLXSL Transformation class
require_once('../../includes/MM_XSLTransform/MM_XSLTransform.class.php'); 
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>XSLT parameter demonstration</title>
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body>
<?php if (!isset($_GET['pub'])) {$_GET['pub'] = 'Apress';} ?>
<form name="form" id="form">
  <select name="pub" id="pub" onchange="MM_jumpMenu('parent',this,0)">
    <option value="?pub=Apress" <?php if (!(strcmp("Apress", $_GET['pub']))) {echo "selected=\"selected\"";} ?>>Apress</option>
    <option value="?pub=friends of ED" <?php if (!(strcmp("friends of ED", $_GET['pub']))) {echo "selected=\"selected\"";} ?>>friends of ED</option>
  </select>
</form>
<?php
$mm_xsl_param1 = "";
if (isset($_GET['pub'])) {
	$mm_xsl_param1 = (get_magic_quotes_gpc()) ? $_GET['pub'] : addslashes($_GET['pub']);
}
$mm_xsl = new MM_XSLTransform();
$mm_xsl->setXML("../../examples/ch18/booklist.xml");
$mm_xsl->setXSL("books9.xsl");
$mm_xsl->addParameter("pub", $mm_xsl_param1);
echo $mm_xsl->Transform();
?></body>
</html>
