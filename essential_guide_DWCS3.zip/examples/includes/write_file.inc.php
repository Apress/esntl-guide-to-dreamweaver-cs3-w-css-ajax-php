<?php
// function to overwrite content in a file
function writeToFile($content, $targetFile) {
  // open the file ready for writing
  if (!$file = fopen($targetFile, 'w')) {
    echo "Cannot create $targetFile";
	exit;
	}
  // write the content to the file
  if (fwrite($file,$content) === false) {
    echo "Cannot write to $targetFile";
	exit;
	}
  echo "Success: content updated in $targetFile";
  // close the file
  fclose($file);
  }
?>