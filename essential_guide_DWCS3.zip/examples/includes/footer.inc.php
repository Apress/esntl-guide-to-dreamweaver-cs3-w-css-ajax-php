<div id="footer">
  <p>&copy;
  <?php
  ini_set('date.timezone', 'Europe/London');
  $startYear = 2007;
  $thisYear = date('Y');
  if ($startYear == $thisYear) {
    echo $startYear;
	}
  else {
    echo "{$startYear}-{$thisYear}";
	}
  ?>
  Footsore in London </p>
  <!-- end #footer -->
</div>
