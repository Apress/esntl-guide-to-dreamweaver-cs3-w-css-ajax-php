<div id="nav">
        <ul id="MenuBar1" class="MenuBarHorizontal">
            <li><a href="#">Home</a>                    </li>
            <li><a href="#" class="MenuBarItemSubmenu">Food &amp; Drink</a>
                <ul>
                    <li><a href="#">Bars</a></li>
                    <li><a href="#">Restaurants</a></li>
                </ul>
            </li>
            <li><a class="MenuBarItemSubmenu" href="#">Attractions</a>
                    <ul>
                        <li><a href="#">London Eye</a>                            </li>
                        <li><a href="#">Aquarium</a></li>
                        <li><a href="#" class="MenuBarItemSubmenu">South Bank</a>
                                <ul>
                                    <li><a href="#">Royal Festival Hall</a></li>
                                    <li><a href="#">Hayward Gallery</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Tate Modern</a></li>
                    </ul>
            </li>
            <li><a href="#">Bridges</a></li>
            <li><a href="#" class="MenuBarItemSubmenu">History</a>
                <ul>
                    <li><a href="#">St Paul's Cathedral</a></li>
                    <li><a href="#">Tower of London</a></li>
                    <li><a href="#">Houses of Parliament</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"../../SpryAssets/SpryMenuBarDownHover.gif", imgRight:"../../SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
