<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_getDetails = "-1";
if (isset($_GET['message_id'])) {
  $colname_getDetails = $_GET['message_id'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getDetails = sprintf("SELECT * FROM feedback WHERE message_id = %s", GetSQLValueString($colname_getDetails, "int"));
$getDetails = mysql_query($query_getDetails, $connQuery) or die(mysql_error());
$row_getDetails = mysql_fetch_assoc($getDetails);
$totalRows_getDetails = mysql_num_rows($getDetails);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Feedback details</title>
<style type="text/css">
body {
	background-color:#fff;
	color:#000;
	font-family:Arial, Helvetica, sans-serif;
	font-size:100%;
	width: 700px;
	}
h1 {
	font-family:Verdana, Arial, Helvetica, sans-serif;
	font-size:140%;
	}
p {
	font-size:85%;
	}
#comments {
	margin-left: 40px;
	}
</style>
</head>

<body>
<h1>Details of feedback from <?php echo $row_getDetails['name']; ?></h1>
<p>On <?php echo $row_getDetails['submitted']; ?>,  <?php echo $row_getDetails['name']; ?> (<?php echo $row_getDetails['email']; ?>) sent the following comments:</p>
<p id="comments"><?php echo nl2br($row_getDetails['comments']); ?></p>
<p><strong>Interests:</strong> <?php echo $row_getDetails['interests']; ?></p>
<p><strong>Frequency of visits:</strong> <?php echo $row_getDetails['visited']; ?></p>
<p><strong>Views on London:</strong> <?php echo $row_getDetails['views']; ?></p>
<p><strong>Subscribe to newsletter:</strong> <?php echo $row_getDetails['subscribe']; ?></p>
</body>
</html>
<?php
mysql_free_result($getDetails);
?>
