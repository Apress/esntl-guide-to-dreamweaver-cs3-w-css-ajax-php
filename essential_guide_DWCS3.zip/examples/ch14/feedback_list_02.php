<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_getFeedback = 10;
$pageNum_getFeedback = 0;
if (isset($_GET['pageNum_getFeedback'])) {
  $pageNum_getFeedback = $_GET['pageNum_getFeedback'];
}
$startRow_getFeedback = $pageNum_getFeedback * $maxRows_getFeedback;

mysql_select_db($database_connQuery, $connQuery);
$query_getFeedback = "SELECT message_id, name, submitted FROM feedback ORDER BY submitted DESC";
$query_limit_getFeedback = sprintf("%s LIMIT %d, %d", $query_getFeedback, $startRow_getFeedback, $maxRows_getFeedback);
$getFeedback = mysql_query($query_limit_getFeedback, $connQuery) or die(mysql_error());
$row_getFeedback = mysql_fetch_assoc($getFeedback);

if (isset($_GET['totalRows_getFeedback'])) {
  $totalRows_getFeedback = $_GET['totalRows_getFeedback'];
} else {
  $all_getFeedback = mysql_query($query_getFeedback);
  $totalRows_getFeedback = mysql_num_rows($all_getFeedback);
}
$totalPages_getFeedback = ceil($totalRows_getFeedback/$maxRows_getFeedback)-1;
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Recent feedback</title>
</head>

<body>
<h1>Feedback summary</h1>
<table width="400">
  <tr>
    <th scope="col">Date and time</th>
    <th scope="col">Name</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_getFeedback['submitted']; ?></td>
      <td><a href="../ch13/feedback_display.php?message_id=<?php echo $row_getFeedback['message_id']; ?>"><?php echo $row_getFeedback['name']; ?></a></td>
    </tr>
    <?php } while ($row_getFeedback = mysql_fetch_assoc($getFeedback)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($getFeedback);
?>
